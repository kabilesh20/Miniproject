package Photolab;

public enum UserRole {
    USER, ADMIN
}
